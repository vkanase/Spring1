package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entities.Trainee;
import com.capgemini.exception.TraineeException;
import com.capgemini.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeService;

	public TraineeController() {
		super();
	}

	public TraineeController(ITraineeService traineeService) {
		super();
		this.traineeService = traineeService;
	}

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}
	
	@RequestMapping("PickOperation")
	public String getOperationPage(@RequestParam("un") String un, @RequestParam("pass") String pass)
	{
		if(un.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin"))
		{
			return "OpeartionPage";
		}
		else
		{
			return "ErrorPage";
		}
		

	}
	
	@RequestMapping("addTrainee")
	public String addTraineePage(Model model)
	{
		System.out.println("manisha");
		List<String> locations = new ArrayList<String>();
		locations.add("Chennai");
		locations.add("Banglore");
		locations.add("Pune");
		locations.add("Mumbai");
		
		List<String> domains = new ArrayList<String>();
		domains.add("java");
		domains.add("Dot.Net");
		domains.add("Testing");
		domains.add("Oracle");
		
		model.addAttribute("location",locations );
		model.addAttribute("domain", domains);
		model.addAttribute("trainee", new Trainee());
		
		System.out.println("Vishal");
		return "AddTraineePage";
	}
		
	
	@RequestMapping("TraineeDetails")
	public  ModelAndView getTraineeDetails(@ModelAttribute("trainee") @Valid Trainee trainee , BindingResult result , Model model ) throws TraineeException
	{
		if(result.hasErrors() == true)
		{
			List<String> locations = new ArrayList<String>();
			locations.add("Chennai");
			locations.add("Banglore");
			locations.add("Pune");
			locations.add("Mumbai");
			
			List<String> domains = new ArrayList<String>();
			domains.add("java");
			domains.add("Dot.Net");
			domains.add("Testing");
			domains.add("Oracle");
			
			model.addAttribute("location",locations );
			model.addAttribute("domain", domains);
			model.addAttribute("trainee", trainee);
			return new ModelAndView("AddTraineePage");
		}
		else
		{
			int traineeId = -1 ;
			try
			{
				traineeId = traineeService.addTrainee(trainee) ;
				model.addAttribute("message","Trainee Added Successfully with id " + traineeId) ;
				return new ModelAndView("SuccessPage");
			}
			catch(Exception e)
			{
				throw new TraineeException(e.getMessage());
			}
			
		
		}
	}

	
	@RequestMapping("getTrainee")
	public String getTraineePage()
	{
		return "RetriveTraineePage";
	}
	
	
	@RequestMapping("traineeDetails")
	public ModelAndView processGetTrainee(@RequestParam("tid") int id)
	{
		Trainee trainee = null ;
		try
		{
			trainee = traineeService.getTrainee(id) ;
			return new ModelAndView("RetriveTraineePage","trainee",trainee);
		}
		catch(Exception e)
		{
			return new ModelAndView("ErrorPage","errMsg","Coudnt Get The Product Reason : "+e.getMessage());
		}
	}
	
	@RequestMapping("deleteTrainee")
	public String getDeletePage()
	{
		return "DeleteTraineePage" ;
	}
	
	@RequestMapping("traineeDetailsToDelete.do")
	public ModelAndView processGetTraineeToDelete(@RequestParam("tid") int id)
	{
		Trainee trainee = null ;
		try
		{
			trainee = traineeService.getTrainee(id) ;
			return new ModelAndView("DeleteTraineePage","trainee",trainee);
		}
		catch(Exception e)
		{
			return new ModelAndView("ErrorPage","errMsg","Coudnt Get The Product Reason : "+e.getMessage());
		}
	}
	
	@RequestMapping("processDelete")
	public String processDelete(@RequestParam("id") int id, Model model)
	{
		try 
		{
			traineeService.removeTrainee(id);
			return "SuccessPage" ;
			
		} catch (Exception e) 
		{
			model.addAttribute("errMsg", "Traine Removed Unsuccessfull for id " + id) ;
			return "ErrorPage" ;
		}
		
	}
	
	
	@RequestMapping("getAllTrainee")
	public String getViewTraineePage(Model model)
	{
		List<Trainee> traineeList = null ;
		try
		{
			traineeList = traineeService.getAllTrainee() ;
			model.addAttribute("traineeList",traineeList) ;
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg","Coudnt Get The TraineeList Reason : "+e.getMessage() );
			return "ErrorPage";
		}
		return "ListTraineePage" ;
	}

}


