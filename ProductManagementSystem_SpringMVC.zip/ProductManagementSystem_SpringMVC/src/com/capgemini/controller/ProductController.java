package com.capgemini.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ProductController 
{
	
}
