package com.capgemini.service;

import java.util.List;

import com.capgemini.dao.IProductDAO;
import com.capgemini.dao.ProductDAOImpl;
import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

public class ProductServiceImpl implements IProductService 
{
	IProductDAO productDAO ;

	public ProductServiceImpl() 
	{
		productDAO = new ProductDAOImpl();
	}
	@Override
	public int addProduct(Product product) throws ProductException 
	{
		return productDAO.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		productDAO.updateProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException 
	{
		return productDAO.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException 
	{
		productDAO.removeProduct(id);
	}
	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getAllProducts();
	}
	@Override
	public Product getProductByName(String name) throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getProductByName(name);
	}
	@Override
	public List<Product> getProductByPrice(float min, float max)
			throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getProductByPrice(min, max);
	}

}
