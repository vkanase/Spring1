package com.capgemini.junit;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class Test
{
	static IProductService productService ;
	public static void main(String[] args) 
	{
		productService = new ProductServiceImpl();
		/*Product product = new Product("C", 5, 5000) ;
		int id = productService.addProduct(product) ;
		
		System.out.println(id);*/
		
	/*	product.setId(9);
		product.setName("ABC");
		
		productService.updateProduct(product);*/
		
		/*Product product = productService.getProduct(9);
		System.out.println(product);*/
		
		
		productService.removeProduct(10);
	  
	}
}
